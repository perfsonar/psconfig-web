
angular.module('app.config', []).constant('appconf', {
    //title to display
    title: 'MeshConfig Admin',

    //url base for meshconfig api
    api: '../api/mca',

    //url base for meshconfig publisher
    pub_url: 'http://'+location.hostname+location.pathname+'pub/',

    //profile_api: '../api/profile',
    //profile_url: '../profile',

    //authentcation service API / UI
    auth_api: '../api/auth',
    auth_url: '../auth',

    jwt_id: 'jwt',
});

