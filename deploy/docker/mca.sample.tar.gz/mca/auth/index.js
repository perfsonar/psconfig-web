//node
var fs = require('fs');
var winston = require('winston');

exports.auth = {
    //default user object when registered
    default: {
        scopes: {
            sca: ["user"],
            mca: ["user"], //needed by mca
        },
        gids: [ /*1*/ ],
    },

    //isser to use for generated jwt token
    iss: "https://sca.iu.edu/auth",
    //ttl for jwt
    ttl: 24*3600*1000, //1 day

    public_key: fs.readFileSync(__dirname+'/auth.pub'),
    private_key: fs.readFileSync(__dirname+'/auth.key'),

    //option for jwt.sign
    sign_opt: {algorithm: 'RS256'},

    //allow_signup: false, //prevent user from signing in
};

//comment this out if you don't want to confirm email
exports.email_confirmation = {
    subject: 'Meshconfign Account Confirmation',
    from: 'hayashis@iu.edu',  //most mail server will reject if this is not eplyable address
};

//for local user/pass login (you should use either local, or ldap - but not both)
exports.local = {
    //url base for callbacks only used if req.header.referer is not set (like via cli)
    //url: 'https://soichi7.ppa.iu.edu/auth',

    //comment this out if you don't want to confirm email
    email_confirmation: {
	    subject: 'Meshconfign Account Confirmation',
	    from: 'hayashis@iu.edu',  //most mail server will reject if this is not eplyable address
    },
    email_passreset: {
	    subject: 'Meshconfign Password Reset',
	    from: 'hayashis@iu.edu',  //most mail server will reject if this is not eplyable address
    }
};

//comme this out to disable iucas
exports.iucas = { };

//for x509
exports.x509 = {
    //http header to look for x509 DN 
    //for nginx set proxy_set_header DN $ssl_client_s_dn
    //for apache, SSLOptions +StdEnvVars will set it to SSL_CLIENT_S_DN
    dn_header: 'dn',
    allow_origin: '*',
};


exports.db = {
    dialect: "sqlite",
    storage: "/db/auth.sqlite",
    logging: false
}

exports.express = {
    //web server port
    host: "0.0.0.0",
    port: 8080,
};

exports.logger = {
    winston: {
        //hide headers which may contain jwt
        requestWhitelist: ['url', /*'headers',*/ 'method', 'httpVersion', 'originalUrl', 'query'],
        transports: [
            //display all logs to console
            new winston.transports.Console({
                timestamp: function() {
                    var d = new Date();
                    return d.toString(); //show timestamp
                },
                level: 'debug',
                colorize: true
            }),
        ]
    }
}


