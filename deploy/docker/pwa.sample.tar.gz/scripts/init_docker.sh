#!/usr/bin/bash

docker network create pwa

mkdir -p /usr/local/data


